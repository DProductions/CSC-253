﻿/**
* 15 OCT 2023
* CSC 253
* Daniel Parks
* Creat Employee table in database and display via DataGridView. Seach and show all included.
* 
*  - on table creation, used "money" for Hourly Rate. This brings a $15.00 to $15.0000
*  
*  **** I copied and practiced directly out of the book. Error when searching. I cannot correct.
*  **** Error with line 53. - redid multiple times with same error. Please help.
* 
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.employeeDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'employeeDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.employeeDataSet.Employee);

        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.SearchDesc2(
                this.employeeDataSet.Employee, textBoxSearch.Text);
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAll_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.Fill(this.employeeDataSet.Employee);
        }
    }
}
public partial class EmployeeTableAdapter
{
    public int SearchByName(EmployeeDataSet.EmployeeDataTable dataTable, string searchText)
    {
        // Implement the search logic here and populate the dataTable based on the "Name" column.
        // For example, you can use SQL queries, LINQ, or any other method to filter the data.

        // Here's a simple example using LINQ to filter based on the "Name" column:
        var query = from row in dataTable
                    where row.Name.Contains(searchText)
                    select row;

        dataTable.Clear();
        dataTable.Merge(query.CopyToDataTable());

        return dataTable.Rows.Count;
    }
}