﻿/**
* 29 OCT 2023
* CSC 253
* Daniel Parks
* List Manipulation
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using LibraryRemoveAndFind;

namespace WinFormUA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonManipulate_Click(object sender, EventArgs e)
        {
            string filePath = textBoxFile.Text;

            if (File.Exists(filePath))
            {
                List<int> originalList = new List<int>();
                List<int> filteredList = new List<int>();

                try
                {
                    // Read the file and add its contents to the originalList.
                    using (StreamReader reader = new StreamReader(filePath))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            if (int.TryParse(line, out int number))
                            {
                                originalList.Add(number);
                            }
                        }
                    }

                    // Create an instance of the Manipulate class from the library.
                    Manipulate manipulator = new Manipulate();

                    // Use the library methods to remove negative numbers and filter the list.
                    manipulator.RemoveNegativeNumbers(originalList);
                    filteredList = manipulator.FilterInRange(originalList, 1, 10);

                    // Clear the ListBox and display the filtered list.
                    listBoxDisplay.Items.Clear();
                    foreach (int item in filteredList)
                    {
                        listBoxDisplay.Items.Add(item);
                    }
                }
                catch (IOException ex)
                {
                    MessageBox.Show($"An error occurred while reading the file: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("File not found. Please enter a valid file path.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    }
