﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryRemoveAndFind
{
    public class Manipulate
    {
        public void RemoveNegativeNumbers(List<int> list)
        {
            list.RemoveAll(item => item < 0);
        }
        public List<int> FilterInRange(List<int> list, int minValue, int maxValue)
        {
            return list.FindAll(item => item >= minValue && item <= maxValue);
        }
    }
}
