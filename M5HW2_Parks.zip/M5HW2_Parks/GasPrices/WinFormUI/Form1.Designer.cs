﻿namespace WinFormUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.averagePricePerYearButton = new System.Windows.Forms.Button();
            this.averagePricePerMonthButton = new System.Windows.Forms.Button();
            this.highestLowestPricesPerYearButton = new System.Windows.Forms.Button();
            this.lowestToHighestButton = new System.Windows.Forms.Button();
            this.highestToLowestButton = new System.Windows.Forms.Button();
            this.openFileButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // averagePricePerYearButton
            // 
            this.averagePricePerYearButton.Location = new System.Drawing.Point(138, 113);
            this.averagePricePerYearButton.Name = "averagePricePerYearButton";
            this.averagePricePerYearButton.Size = new System.Drawing.Size(183, 23);
            this.averagePricePerYearButton.TabIndex = 1;
            this.averagePricePerYearButton.Text = "Average Price";
            this.averagePricePerYearButton.UseVisualStyleBackColor = true;
            this.averagePricePerYearButton.Click += new System.EventHandler(this.averagePricePerYearButton_Click);
            // 
            // averagePricePerMonthButton
            // 
            this.averagePricePerMonthButton.Location = new System.Drawing.Point(138, 152);
            this.averagePricePerMonthButton.Name = "averagePricePerMonthButton";
            this.averagePricePerMonthButton.Size = new System.Drawing.Size(183, 23);
            this.averagePricePerMonthButton.TabIndex = 2;
            this.averagePricePerMonthButton.Text = "Average Price Per Month";
            this.averagePricePerMonthButton.UseVisualStyleBackColor = true;
            this.averagePricePerMonthButton.Click += new System.EventHandler(this.averagePricePerMonthButton_Click);
            // 
            // highestLowestPricesPerYearButton
            // 
            this.highestLowestPricesPerYearButton.Location = new System.Drawing.Point(138, 190);
            this.highestLowestPricesPerYearButton.Name = "highestLowestPricesPerYearButton";
            this.highestLowestPricesPerYearButton.Size = new System.Drawing.Size(183, 23);
            this.highestLowestPricesPerYearButton.TabIndex = 3;
            this.highestLowestPricesPerYearButton.Text = "Highest to Lowest Prices per year\r\n";
            this.highestLowestPricesPerYearButton.UseVisualStyleBackColor = true;
            this.highestLowestPricesPerYearButton.Click += new System.EventHandler(this.highestLowestPricesPerYearButton_Click);
            // 
            // lowestToHighestButton
            // 
            this.lowestToHighestButton.Location = new System.Drawing.Point(138, 230);
            this.lowestToHighestButton.Name = "lowestToHighestButton";
            this.lowestToHighestButton.Size = new System.Drawing.Size(183, 23);
            this.lowestToHighestButton.TabIndex = 4;
            this.lowestToHighestButton.Text = "Lowest to Highest Prices";
            this.lowestToHighestButton.UseVisualStyleBackColor = true;
            this.lowestToHighestButton.Click += new System.EventHandler(this.lowestToHighestButton_Click);
            // 
            // highestToLowestButton
            // 
            this.highestToLowestButton.Location = new System.Drawing.Point(138, 278);
            this.highestToLowestButton.Name = "highestToLowestButton";
            this.highestToLowestButton.Size = new System.Drawing.Size(183, 23);
            this.highestToLowestButton.TabIndex = 5;
            this.highestToLowestButton.Text = "Highest to Lowest Prices";
            this.highestToLowestButton.UseVisualStyleBackColor = true;
            this.highestToLowestButton.Click += new System.EventHandler(this.highestToLowestButton_Click);
            // 
            // openFileButton
            // 
            this.openFileButton.Location = new System.Drawing.Point(12, 190);
            this.openFileButton.Name = "openFileButton";
            this.openFileButton.Size = new System.Drawing.Size(75, 23);
            this.openFileButton.TabIndex = 6;
            this.openFileButton.Text = "Open File";
            this.openFileButton.UseVisualStyleBackColor = true;
            this.openFileButton.Click += new System.EventHandler(this.openFileButton_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(292, 78);
            this.label1.TabIndex = 7;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 332);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.openFileButton);
            this.Controls.Add(this.highestToLowestButton);
            this.Controls.Add(this.lowestToHighestButton);
            this.Controls.Add(this.highestLowestPricesPerYearButton);
            this.Controls.Add(this.averagePricePerMonthButton);
            this.Controls.Add(this.averagePricePerYearButton);
            this.Name = "Form1";
            this.Text = "Gas Prices";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button averagePricePerYearButton;
        private System.Windows.Forms.Button averagePricePerMonthButton;
        private System.Windows.Forms.Button highestLowestPricesPerYearButton;
        private System.Windows.Forms.Button lowestToHighestButton;
        private System.Windows.Forms.Button highestToLowestButton;
        private System.Windows.Forms.Button openFileButton;
        private System.Windows.Forms.Label label1;
    }
}

