﻿/**
* 19 Nov 2023
* CSC 253
* Daniel Parks
* Sort through file of gas prices /years and sort based on book requirments
*/


using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        private List<GasRecord> gasRecords = new List<GasRecord>();
        public Form1()
        {
            InitializeComponent();
        }

        private void openFileButton_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                LoadGasRecords(filePath);
            }
        }
        private void LoadGasRecords(string filePath)
        {
            string[] lines = File.ReadAllLines(filePath);

            gasRecords = lines.Select(line =>
            {
                string[] parts = line.Split(':');
                if (parts.Length == 2 && decimal.TryParse(parts[1], NumberStyles.Float, CultureInfo.InvariantCulture, out decimal price) &&
                    DateTime.TryParseExact(parts[0], "MM-dd-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                {
                    return new GasRecord { Date = date, Price = price };
                }
                return null;
            })
            .Where(record => record != null)
            .ToList();
        }
        private void averagePricePerYearButton_Click(object sender, EventArgs e)
        {
            var averagePricesPerYear = gasRecords.GroupBy(record => record.Date.Year)
                .Select(group => new
                {
                    Year = group.Key,
                    AveragePrice = group.Average(record => record.Price)
                });

            SaveToFileOnDesktop("AveragePricePerYear.txt", averagePricesPerYear.Select(result => $"{result.Year}: {result.AveragePrice}"));
        }

        private void averagePricePerMonthButton_Click(object sender, EventArgs e)
        {
            var averagePricesPerMonth = gasRecords.GroupBy(record => new { record.Date.Year, record.Date.Month })
                .Select(group => new
                {
                    Year = group.Key.Year,
                    Month = group.Key.Month,
                    AveragePrice = group.Average(record => record.Price)
                });

            SaveToFileOnDesktop("AveragePricePerMonth.txt", averagePricesPerMonth.Select(result => $"{result.Year}-{result.Month}: {result.AveragePrice}"));
        }

        private void highestLowestPricesPerYearButton_Click(object sender, EventArgs e)
        {
            var highestLowestPricesPerYear = gasRecords.GroupBy(record => record.Date.Year)
                .Select(group => new
                {
                    Year = group.Key,
                    HighestPrice = group.Max(record => record.Price),
                    LowestPrice = group.Min(record => record.Price)
                });

            SaveToFileOnDesktop("HighestLowestPricesPerYear.txt", highestLowestPricesPerYear.Select(result => $"{result.Year}: Highest Price - {result.HighestPrice}, Lowest Price - {result.LowestPrice}"));
        }

        private void lowestToHighestButton_Click(object sender, EventArgs e)
        {
            var sortedPrices = gasRecords.OrderBy(record => record.Price)
                .Select(record => $"{record.Date.ToString("MM-dd-yyyy", CultureInfo.InvariantCulture)}: {record.Price}");

            SaveToFileOnDesktop("PricesLowestToHighest.txt", sortedPrices);
        }

        private void highestToLowestButton_Click(object sender, EventArgs e)
        {
            var sortedPrices = gasRecords.OrderByDescending(record => record.Price)
                .Select(record => $"{record.Date.ToString("MM-dd-yyyy", CultureInfo.InvariantCulture)}: {record.Price}");

            SaveToFileOnDesktop("PricesHighestToLowest.txt", sortedPrices);
        }
        private void SaveToFileOnDesktop(string fileName, IEnumerable<string> lines)
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string filePath = Path.Combine(desktopPath, fileName);

            File.WriteAllLines(filePath, lines);

            MessageBox.Show($"File '{fileName}' saved on the desktop.");
        }
    }



    public class GasRecord
    {
        public DateTime Date { get; set; }
        public decimal Price { get; set; }
    }
}
