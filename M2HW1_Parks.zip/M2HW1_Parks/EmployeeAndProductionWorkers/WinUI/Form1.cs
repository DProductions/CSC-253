﻿/**
* 24 SEP 2023
* CSC 253
* Daniel Parks
* 
* 
* Project Description:
* Create an Employee class that has propertis for the following data:
*
*    - Employee name
*    - Employee number

* Next, create a class named ProductionWorker that is derived from the Employee class. 
* The ProductionWorker class should have propertis to hold the following data:
*
*    - Shift number (an integer, such as 1,2, or 3)
*    - Hourly pay rate
*
* The workday is divided into two shifts: day and night. The Shift property will hold 
* an integer value representing the shift that the employee works. The day shift is 
* shift 1 and the night shift is shift 2.

* Create an application that creates an object of the ProductionWorker class and lets 
* the user enter data for each of the object's properties. Retrieve the object's 
* properties and display their values.
* 
* 
*    ***Application does not save user input. Only displays last entery, if any.***
*/


using System;
using System.Windows.Forms;
using Employees;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public ProductionWorker currentEmployee;

        public Form1()
        {
            InitializeComponent();
        }

        // Exit Button - Close
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        // Create Employee Button and evaluate each textbox for valid response
        public void buttonCreateEmployee_Click(object sender, EventArgs e)
        {
            currentEmployee = new ProductionWorker();

            currentEmployee.EmployeeName = textBoxEmployeeName.Text;

            if (int.TryParse(textBoxEmployeeNumber.Text, out int empNumber))
            {
                currentEmployee.EmployeeNumber = empNumber;
            }
            else
            {
                MessageBox.Show("Invalid Employee Number. Using default value 0.");
                currentEmployee.EmployeeNumber = 0;
            }

            if (int.TryParse(textBoxShiftNumber.Text, out int shift))
            {
                if (shift == 1 || shift == 2)
                {
                    currentEmployee.Shift = shift;
                }
                else
                {
                    MessageBox.Show("Invalid Shift. Using default value 1 (day shift).");
                    currentEmployee.Shift = 1;
                }
            }
            else
            {
                MessageBox.Show("Invalid Shift. Using default value 1 (day shift).");
                currentEmployee.Shift = 1;
            }

            if (double.TryParse(textBoxHourlyRate.Text, out double hourlyPayRate))
            {
                currentEmployee.HourlyPayRate = hourlyPayRate;
            }
            else
            {
                MessageBox.Show("Invalid Hourly Pay Rate. Using default value 0.00.");
                currentEmployee.HourlyPayRate = 0.00;
            }

            MessageBox.Show("Employee created successfully!");
        }


        // Search Employee Button - Check for valid response - search and display valid responses
        public void buttonSearchEmployeeNumber_Click(object sender, EventArgs e)
        {
            if (currentEmployee != null)
            {
                MessageBox.Show($"Employee Information:\nEmployee Name: {currentEmployee.EmployeeName}\nEmployee Number: {currentEmployee.EmployeeNumber}\nShift: {(currentEmployee.Shift == 1 ? "Day" : "Night")}\nHourly Pay Rate: {currentEmployee.HourlyPayRate.ToString("C2")}");
            }
            else
            {
                MessageBox.Show("No employee data found. Create an employee first.");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
