﻿/**
* 15 OCT 2023
* CSC 253
* Daniel Parks
* 
* M3HW3
* Copy of M3HW1 with added Highest Pay and Lowest Pay buttonws. 
* 
*  
* 
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.employeeDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.employeeTableAdapter.Fill(this.employeeDataSet.Employee);

        }

        private void buttonClost_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonHighest_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Personnel.mdf;Integrated Security=True;"))

            {
                connection.Open();

                string query = "SELECT MAX([Hourly Rate]) FROM Employee";
                SqlCommand command = new SqlCommand(query, connection);
                decimal highestPayRate = (decimal)command.ExecuteScalar();

                MessageBox.Show($"Highest Pay Rate: {highestPayRate:C}");
            }
        }

        private void buttonLowest_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Personnel.mdf;Integrated Security=True;"))
            {
                connection.Open();

                string query = "SELECT MIN([Hourly Rate]) FROM Employee";
                SqlCommand command = new SqlCommand(query, connection);
                decimal lowestPayRate = (decimal)command.ExecuteScalar();

                MessageBox.Show($"Lowest Pay Rate: {lowestPayRate:C}");
            }
        }

        private void employeeDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
