﻿/**
* 14 SEP 2023
* Daniel Parks
* Word Index
* 
*/



using System;
using System.Collections.Generic;
using System.IO;

namespace DictionaryProcess
{
    public class FileProcessor
    {
        public static Dictionary<string, List<int>> CreateWordIndex(string filePath)
        {
            try
            {
                Dictionary<string, List<int>> wordIndex = new Dictionary<string, List<int>>();
                string[] lines = File.ReadAllLines(filePath);

                for (int lineNumber = 1; lineNumber <= lines.Length; lineNumber++)
                {
                    string[] words = lines[lineNumber - 1].Split(' ');

                    foreach (string word in words)
                    {
                        string cleanedWord = word.Trim();

                        if (!string.IsNullOrEmpty(cleanedWord))
                        {
                            if (!wordIndex.ContainsKey(cleanedWord))
                            {
                                wordIndex[cleanedWord] = new List<int>();
                            }

                            wordIndex[cleanedWord].Add(lineNumber);
                        }
                    }
                }

                return wordIndex;
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred: " + ex.Message);
            }
        }

        public static bool SaveWordIndexToFile(Dictionary<string, List<int>> wordIndex, string saveFilePath)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(saveFilePath))
                {
                    foreach (var entry in wordIndex)
                    {
                        writer.WriteLine($"{entry.Key}: {string.Join(", ", entry.Value)}");
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while saving the word index: " + ex.Message);
            }
        }
    }
}