﻿/**
* 14 SEP 2023
* Daniel Parks
* Word Index
* 
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using DictionaryProcess;

namespace WinFormUI
{
    public partial class WordIndex : Form
    {
        public WordIndex()
        {
            InitializeComponent();
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void startIndexButton_Click(object sender, EventArgs e)
        {
            string inputFile = loadFileTextBox.Text;
            string saveFilePath = saveFileTextBox.Text;

            if (!File.Exists(inputFile))
            {
                MessageBox.Show("Please enter a valid file/file path");
                return;
            }

            Dictionary<string, List<int>> wordIndex = FileProcessor.CreateWordIndex(inputFile);

            if (wordIndex != null)
            {
                if (FileProcessor.SaveWordIndexToFile(wordIndex, saveFilePath))
                {
                    MessageBox.Show($"Word index saved to '{saveFilePath}'");
                }
                else
                {
                    MessageBox.Show("An error occurred while saving the word index.");
                }
            }
            else
            {
                MessageBox.Show("An error occurred while processing the file.");
            }
        }
    }
}