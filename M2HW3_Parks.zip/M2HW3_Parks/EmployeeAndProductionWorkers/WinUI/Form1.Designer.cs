﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonCreateEmployee = new System.Windows.Forms.Button();
            this.buttonSearchEmployeeNumber = new System.Windows.Forms.Button();
            this.labelEmployeeName = new System.Windows.Forms.Label();
            this.labelEmployeeNumber = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelHourlyRate = new System.Windows.Forms.Label();
            this.textBoxEmployeeNumber = new System.Windows.Forms.TextBox();
            this.textBoxEmployeeName = new System.Windows.Forms.TextBox();
            this.textBoxShiftNumber = new System.Windows.Forms.TextBox();
            this.textBoxHourlyRate = new System.Windows.Forms.TextBox();
            this.textBoxMonthlyBonus = new System.Windows.Forms.TextBox();
            this.textBoxRequiredTraining = new System.Windows.Forms.TextBox();
            this.textBoxAttendedTraining = new System.Windows.Forms.TextBox();
            this.buttonCreateTeamLeader = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(212, 351);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(104, 29);
            this.buttonExit.TabIndex = 0;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonCreateEmployee
            // 
            this.buttonCreateEmployee.Location = new System.Drawing.Point(52, 316);
            this.buttonCreateEmployee.Name = "buttonCreateEmployee";
            this.buttonCreateEmployee.Size = new System.Drawing.Size(104, 29);
            this.buttonCreateEmployee.TabIndex = 1;
            this.buttonCreateEmployee.Text = "Create Employee";
            this.buttonCreateEmployee.UseVisualStyleBackColor = true;
            this.buttonCreateEmployee.Click += new System.EventHandler(this.buttonCreateEmployee_Click);
            // 
            // buttonSearchEmployeeNumber
            // 
            this.buttonSearchEmployeeNumber.BackColor = System.Drawing.SystemColors.Window;
            this.buttonSearchEmployeeNumber.Location = new System.Drawing.Point(212, 318);
            this.buttonSearchEmployeeNumber.Name = "buttonSearchEmployeeNumber";
            this.buttonSearchEmployeeNumber.Size = new System.Drawing.Size(108, 27);
            this.buttonSearchEmployeeNumber.TabIndex = 2;
            this.buttonSearchEmployeeNumber.Text = "Search Employee Number";
            this.buttonSearchEmployeeNumber.UseVisualStyleBackColor = false;
            this.buttonSearchEmployeeNumber.Click += new System.EventHandler(this.buttonSearchEmployeeNumber_Click);
            // 
            // labelEmployeeName
            // 
            this.labelEmployeeName.AutoSize = true;
            this.labelEmployeeName.Location = new System.Drawing.Point(34, 71);
            this.labelEmployeeName.Name = "labelEmployeeName";
            this.labelEmployeeName.Size = new System.Drawing.Size(84, 13);
            this.labelEmployeeName.TabIndex = 3;
            this.labelEmployeeName.Text = "Employee Name";
            // 
            // labelEmployeeNumber
            // 
            this.labelEmployeeNumber.AutoSize = true;
            this.labelEmployeeNumber.Location = new System.Drawing.Point(34, 35);
            this.labelEmployeeNumber.Name = "labelEmployeeNumber";
            this.labelEmployeeNumber.Size = new System.Drawing.Size(93, 13);
            this.labelEmployeeNumber.TabIndex = 4;
            this.labelEmployeeNumber.Text = "Employee Number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 26);
            this.label1.TabIndex = 5;
            this.label1.Text = "Shift Number:\r\n(1=Day, 2=Night)\r\n";
            // 
            // labelHourlyRate
            // 
            this.labelHourlyRate.AutoSize = true;
            this.labelHourlyRate.Location = new System.Drawing.Point(34, 151);
            this.labelHourlyRate.Name = "labelHourlyRate";
            this.labelHourlyRate.Size = new System.Drawing.Size(63, 13);
            this.labelHourlyRate.TabIndex = 6;
            this.labelHourlyRate.Text = "Hourly Rate";
            // 
            // textBoxEmployeeNumber
            // 
            this.textBoxEmployeeNumber.Location = new System.Drawing.Point(220, 32);
            this.textBoxEmployeeNumber.Name = "textBoxEmployeeNumber";
            this.textBoxEmployeeNumber.Size = new System.Drawing.Size(100, 20);
            this.textBoxEmployeeNumber.TabIndex = 7;
            // 
            // textBoxEmployeeName
            // 
            this.textBoxEmployeeName.Location = new System.Drawing.Point(220, 68);
            this.textBoxEmployeeName.Name = "textBoxEmployeeName";
            this.textBoxEmployeeName.Size = new System.Drawing.Size(100, 20);
            this.textBoxEmployeeName.TabIndex = 8;
            // 
            // textBoxShiftNumber
            // 
            this.textBoxShiftNumber.Location = new System.Drawing.Point(220, 113);
            this.textBoxShiftNumber.Name = "textBoxShiftNumber";
            this.textBoxShiftNumber.Size = new System.Drawing.Size(100, 20);
            this.textBoxShiftNumber.TabIndex = 9;
            // 
            // textBoxHourlyRate
            // 
            this.textBoxHourlyRate.Location = new System.Drawing.Point(220, 151);
            this.textBoxHourlyRate.Name = "textBoxHourlyRate";
            this.textBoxHourlyRate.Size = new System.Drawing.Size(100, 20);
            this.textBoxHourlyRate.TabIndex = 10;
            // 
            // textBoxMonthlyBonus
            // 
            this.textBoxMonthlyBonus.Location = new System.Drawing.Point(220, 195);
            this.textBoxMonthlyBonus.Name = "textBoxMonthlyBonus";
            this.textBoxMonthlyBonus.Size = new System.Drawing.Size(100, 20);
            this.textBoxMonthlyBonus.TabIndex = 11;
            // 
            // textBoxRequiredTraining
            // 
            this.textBoxRequiredTraining.Location = new System.Drawing.Point(220, 233);
            this.textBoxRequiredTraining.Name = "textBoxRequiredTraining";
            this.textBoxRequiredTraining.Size = new System.Drawing.Size(100, 20);
            this.textBoxRequiredTraining.TabIndex = 12;
            // 
            // textBoxAttendedTraining
            // 
            this.textBoxAttendedTraining.Location = new System.Drawing.Point(220, 267);
            this.textBoxAttendedTraining.Name = "textBoxAttendedTraining";
            this.textBoxAttendedTraining.Size = new System.Drawing.Size(100, 20);
            this.textBoxAttendedTraining.TabIndex = 13;
            // 
            // buttonCreateTeamLeader
            // 
            this.buttonCreateTeamLeader.BackColor = System.Drawing.SystemColors.Window;
            this.buttonCreateTeamLeader.Location = new System.Drawing.Point(52, 351);
            this.buttonCreateTeamLeader.Name = "buttonCreateTeamLeader";
            this.buttonCreateTeamLeader.Size = new System.Drawing.Size(108, 27);
            this.buttonCreateTeamLeader.TabIndex = 14;
            this.buttonCreateTeamLeader.Text = "Create Team leader";
            this.buttonCreateTeamLeader.UseVisualStyleBackColor = false;
            this.buttonCreateTeamLeader.Click += new System.EventHandler(this.buttonCreateTeamLeader_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 198);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "Monthly Bonus";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 240);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Training hours for bonus";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 274);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(126, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Training hours completed";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 430);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonCreateTeamLeader);
            this.Controls.Add(this.textBoxAttendedTraining);
            this.Controls.Add(this.textBoxRequiredTraining);
            this.Controls.Add(this.textBoxMonthlyBonus);
            this.Controls.Add(this.textBoxHourlyRate);
            this.Controls.Add(this.textBoxShiftNumber);
            this.Controls.Add(this.textBoxEmployeeName);
            this.Controls.Add(this.textBoxEmployeeNumber);
            this.Controls.Add(this.labelHourlyRate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelEmployeeNumber);
            this.Controls.Add(this.labelEmployeeName);
            this.Controls.Add(this.buttonSearchEmployeeNumber);
            this.Controls.Add(this.buttonCreateEmployee);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Team Leader";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonCreateEmployee;
        private System.Windows.Forms.Button buttonSearchEmployeeNumber;
        private System.Windows.Forms.Label labelEmployeeName;
        private System.Windows.Forms.Label labelEmployeeNumber;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelHourlyRate;
        private System.Windows.Forms.TextBox textBoxEmployeeNumber;
        private System.Windows.Forms.TextBox textBoxEmployeeName;
        private System.Windows.Forms.TextBox textBoxShiftNumber;
        private System.Windows.Forms.TextBox textBoxHourlyRate;
        private System.Windows.Forms.TextBox textBoxMonthlyBonus;
        private System.Windows.Forms.TextBox textBoxRequiredTraining;
        private System.Windows.Forms.TextBox textBoxAttendedTraining;
        private System.Windows.Forms.Button buttonCreateTeamLeader;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

