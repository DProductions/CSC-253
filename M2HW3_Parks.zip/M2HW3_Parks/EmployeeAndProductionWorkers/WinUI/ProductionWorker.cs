﻿namespace WinUI
{
    public class ProductionWorker
    {
        public string EmployeeName;
        internal int EmployeeNumber;
        internal double HourlyPayRate;
        public int Shift { get; internal set; }
    }

    public class TeamLeader : ProductionWorker
    {
        public double MonthlyBonus { get; set; }
        public int RequiredTrainingHours { get; set; }
        public int AttendedTrainingHours { get; set; }
    }
}