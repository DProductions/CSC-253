﻿/**
* 01 OCT 2023
* CSC 253
* Daniel Parks
* 
* 
* Project Description:
* M2HW3 - TeamLeader Class
* 
*/


using System;
using System.Windows.Forms;
using Employees;
using System.IO;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public ProductionWorker currentEmployee;
        public TeamLeader currentTeamLeader;

        public Form1()
        {
            InitializeComponent();
        }

        // Exit Button - Close
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        // Create Employee Button and evaluate each textbox for valid response
        public void buttonCreateEmployee_Click(object sender, EventArgs e)
        {
            currentEmployee = new ProductionWorker();

            currentEmployee.EmployeeName = textBoxEmployeeName.Text;

            if (int.TryParse(textBoxEmployeeNumber.Text, out int empNumber))
            {
                currentEmployee.EmployeeNumber = empNumber;
            }
            else
            {
                MessageBox.Show("Invalid Employee Number. Using default value 0.");
                currentEmployee.EmployeeNumber = 0;
            }

            if (int.TryParse(textBoxShiftNumber.Text, out int shift))
            {
                if (shift == 1 || shift == 2)
                {
                    currentEmployee.Shift = shift;
                }
                else
                {
                    MessageBox.Show("Invalid Shift. Using default value 1 (day shift).");
                    currentEmployee.Shift = 1;
                }
            }
            else
            {
                MessageBox.Show("Invalid Shift. Using default value 1 (day shift).");
                currentEmployee.Shift = 1;
            }

            if (double.TryParse(textBoxHourlyRate.Text, out double hourlyPayRate))
            {
                currentEmployee.HourlyPayRate = hourlyPayRate;
            }
            else
            {
                MessageBox.Show("Invalid Hourly Pay Rate. Using default value 0.00.");
                currentEmployee.HourlyPayRate = 0.00;
            }

            MessageBox.Show("Employee created successfully!");

            MessageBox.Show($"Employee Information:\n" +
                            $"Employee Name: {currentEmployee.EmployeeName}\n" +
                            $"Employee Number: {currentEmployee.EmployeeNumber}\n" +
                            $"Shift: {(currentEmployee.Shift == 1 ? "Day" : "Night")}\n" +
                            $"Hourly Pay Rate: {currentEmployee.HourlyPayRate:C2}");
        }


        // Search Employee Button - Check for valid response - search and display valid responses
        public void buttonSearchEmployeeNumber_Click(object sender, EventArgs e)
        {
            int searchEmployeeNumber;

            if (int.TryParse(textBoxEmployeeNumber.Text, out searchEmployeeNumber))
            {
                string filePath = @"C:\Users\adamp\Desktop\M2HW1_Parks\EmployeeAndProductionWorkers\WinUI\employee.txt";

                // Check if the text file exists
                if (File.Exists(filePath))
                {
                    string[] lines = File.ReadAllLines(filePath);
                    string employeeInfo = "";
                    bool foundEmployee = false;

                    foreach (string line in lines)
                    {
                        if (line.StartsWith("Employee Number: "))
                        {
                            int employeeNumber;
                            if (int.TryParse(line.Replace("Employee Number: ", ""), out employeeNumber) && employeeNumber == searchEmployeeNumber)
                            {
                                foundEmployee = true;
                                employeeInfo += line + "\n"; // Include Employee Number
                            }
                            else
                            {
                                employeeInfo = ""; // Reset if the Employee Number doesn't match
                            }
                        }
                        else
                        {
                            employeeInfo += line + "\n"; // Add other employee information
                        }

                        if (line == "")
                        {
                            if (foundEmployee)
                            {
                                // Employee found in the text file
                                MessageBox.Show("Employee Information:\n" + employeeInfo);
                                return;
                            }
                            else
                            {
                                // Reset for the next employee record
                                employeeInfo = "";
                            }
                        }
                    }
                }

                // Employee not found
                MessageBox.Show("Not a valid employee.");
            }
            else
            {
                MessageBox.Show("Invalid Employee Number entered for search.");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonCreateTeamLeader_Click(object sender, EventArgs e)
        {

            currentTeamLeader = new TeamLeader();

            currentTeamLeader.EmployeeName = textBoxEmployeeName.Text;

            if (int.TryParse(textBoxEmployeeNumber.Text, out int empNumber))
            {
                currentTeamLeader.EmployeeNumber = empNumber;
            }
            else
            {
                MessageBox.Show("Invalid Employee Number. Using default value 0.");
                currentTeamLeader.EmployeeNumber = 0;
            }

            if (int.TryParse(textBoxShiftNumber.Text, out int shift))
            {
                if (shift == 1 || shift == 2)
                {
                    currentTeamLeader.Shift = shift;
                }
                else
                {
                    MessageBox.Show("Invalid Shift. Using default value 1 (day shift).");
                    currentTeamLeader.Shift = 1;
                }
            }
            else
            {
                MessageBox.Show("Invalid Shift. Using default value 1 (day shift).");
                currentTeamLeader.Shift = 1;
            }

            if (double.TryParse(textBoxHourlyRate.Text, out double hourlyPayRate))
            {
                currentTeamLeader.HourlyPayRate = hourlyPayRate;
            }
            else
            {
                MessageBox.Show("Invalid Hourly Pay Rate. Using default value 0.00.");
                currentTeamLeader.HourlyPayRate = 0.00;
            }

            if (double.TryParse(textBoxMonthlyBonus.Text, out double monthlyBonus))
            {
                currentTeamLeader.MonthlyBonus = monthlyBonus;
            }
            else
            {
                MessageBox.Show("Invalid Monthly Bonus. Using default value 0.00.");
                currentTeamLeader.MonthlyBonus = 0.00;
            }

            if (int.TryParse(textBoxRequiredTraining.Text, out int requiredTrainingHours))
            {
                currentTeamLeader.RequiredTrainingHours = requiredTrainingHours;
            }
            else
            {
                MessageBox.Show("Invalid Required Training Hours. Using default value 0.");
                currentTeamLeader.RequiredTrainingHours = 0;
            }

            if (int.TryParse(textBoxAttendedTraining.Text, out int attendedTrainingHours))
            {
                currentTeamLeader.AttendedTrainingHours = attendedTrainingHours;
            }
            else
            {
                MessageBox.Show("Invalid Attended Training Hours. Using default value 0.");
                currentTeamLeader.AttendedTrainingHours = 0;
            }

            MessageBox.Show("Team Leader created successfully!");

            MessageBox.Show($"Team Leader Information:\n" +
                            $"Employee Name: {currentTeamLeader.EmployeeName}\n" +
                            $"Employee Number: {currentTeamLeader.EmployeeNumber}\n" +
                            $"Shift: {(currentTeamLeader.Shift == 1 ? "Day" : "Night")}\n" +
                            $"Hourly Pay Rate: {currentTeamLeader.HourlyPayRate:C2}\n" +
                            $"Monthly Bonus: {currentTeamLeader.MonthlyBonus:C2}\n" +
                            $"Required Training Hours: {currentTeamLeader.RequiredTrainingHours}\n" +
                            $"Attended Training Hours: {currentTeamLeader.AttendedTrainingHours}");
        }

        private void SaveEmployeeToTextFile(Employee employee)
        {
            string filePath = "employees.txt";

            // Create or append to the text file
            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine($"Employee Name: {employee.EmployeeName}");
                writer.WriteLine($"Employee Number: {employee.EmployeeNumber}");
                writer.WriteLine($"Shift: {employee.Shift}");
                writer.WriteLine($"Hourly Pay Rate: {employee.HourlyPayRate:C2}");
                writer.WriteLine(); // Add an empty line to separate employee records
            }
        }
    }
}
