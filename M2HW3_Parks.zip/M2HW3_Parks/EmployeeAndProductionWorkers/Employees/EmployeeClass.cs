﻿/**
* 01 OCT 2023
* CSC 253
* Daniel Parks
* 
* 
* Project Description:
* M2HW3 - TeamLeader Class
* 
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
    public class Employee
    {
        public string EmployeeName { get; set; }
        public int EmployeeNumber { get; set; }
        public object HourlyPayRate { get; set; }
        public object Shift { get; set; }
    }

    public class ProductionWorker : Employee
    {
        public int Shift { get; set; }
        public double HourlyPayRate { get; set; }
    }
}
