﻿/**
* 26 Nov 2023
* CSC 253
* Daniel Parks
* Search products based off price from database
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonSelectFile_Click(object sender, EventArgs e)
        {
            MessageBox.Show(text: "Did not complete.");
        }

        private void buttonSearchByProductNumber_Click(object sender, EventArgs e)
        {
            MessageBox.Show(text: "Did not complete.");
        }

        private void buttonSearchByDescription_Click(object sender, EventArgs e)
        {
            MessageBox.Show(text: "Did not complete.");
        }
    }
}
