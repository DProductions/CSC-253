﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonCreateEmployee = new System.Windows.Forms.Button();
            this.buttonSearchEmployeeNumber = new System.Windows.Forms.Button();
            this.labelEmployeeName = new System.Windows.Forms.Label();
            this.labelEmployeeNumber = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelHourlyRate = new System.Windows.Forms.Label();
            this.textBoxEmployeeNumber = new System.Windows.Forms.TextBox();
            this.textBoxEmployeeName = new System.Windows.Forms.TextBox();
            this.textBoxShiftNumber = new System.Windows.Forms.TextBox();
            this.textBoxHourlyRate = new System.Windows.Forms.TextBox();
            this.selectShiftSupervisor = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(198, 241);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(104, 29);
            this.buttonExit.TabIndex = 0;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonCreateEmployee
            // 
            this.buttonCreateEmployee.Location = new System.Drawing.Point(50, 242);
            this.buttonCreateEmployee.Name = "buttonCreateEmployee";
            this.buttonCreateEmployee.Size = new System.Drawing.Size(104, 29);
            this.buttonCreateEmployee.TabIndex = 1;
            this.buttonCreateEmployee.Text = "Create Employee";
            this.buttonCreateEmployee.UseVisualStyleBackColor = true;
            this.buttonCreateEmployee.Click += new System.EventHandler(this.buttonCreateEmployee_Click);
            // 
            // buttonSearchEmployeeNumber
            // 
            this.buttonSearchEmployeeNumber.BackColor = System.Drawing.SystemColors.Window;
            this.buttonSearchEmployeeNumber.Location = new System.Drawing.Point(92, 277);
            this.buttonSearchEmployeeNumber.Name = "buttonSearchEmployeeNumber";
            this.buttonSearchEmployeeNumber.Size = new System.Drawing.Size(162, 27);
            this.buttonSearchEmployeeNumber.TabIndex = 2;
            this.buttonSearchEmployeeNumber.Text = "Search Employee Number";
            this.buttonSearchEmployeeNumber.UseVisualStyleBackColor = false;
            this.buttonSearchEmployeeNumber.Click += new System.EventHandler(this.buttonSearchEmployeeNumber_Click);
            // 
            // labelEmployeeName
            // 
            this.labelEmployeeName.AutoSize = true;
            this.labelEmployeeName.Location = new System.Drawing.Point(34, 71);
            this.labelEmployeeName.Name = "labelEmployeeName";
            this.labelEmployeeName.Size = new System.Drawing.Size(84, 13);
            this.labelEmployeeName.TabIndex = 3;
            this.labelEmployeeName.Text = "Employee Name";
            // 
            // labelEmployeeNumber
            // 
            this.labelEmployeeNumber.AutoSize = true;
            this.labelEmployeeNumber.Location = new System.Drawing.Point(34, 35);
            this.labelEmployeeNumber.Name = "labelEmployeeNumber";
            this.labelEmployeeNumber.Size = new System.Drawing.Size(93, 13);
            this.labelEmployeeNumber.TabIndex = 4;
            this.labelEmployeeNumber.Text = "Employee Number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 26);
            this.label1.TabIndex = 5;
            this.label1.Text = "Shift Number:\r\n(1=Day, 2=Night)\r\n";
            // 
            // labelHourlyRate
            // 
            this.labelHourlyRate.AutoSize = true;
            this.labelHourlyRate.Location = new System.Drawing.Point(34, 151);
            this.labelHourlyRate.Name = "labelHourlyRate";
            this.labelHourlyRate.Size = new System.Drawing.Size(63, 13);
            this.labelHourlyRate.TabIndex = 6;
            this.labelHourlyRate.Text = "Hourly Rate";
            // 
            // textBoxEmployeeNumber
            // 
            this.textBoxEmployeeNumber.Location = new System.Drawing.Point(220, 32);
            this.textBoxEmployeeNumber.Name = "textBoxEmployeeNumber";
            this.textBoxEmployeeNumber.Size = new System.Drawing.Size(100, 20);
            this.textBoxEmployeeNumber.TabIndex = 7;
            // 
            // textBoxEmployeeName
            // 
            this.textBoxEmployeeName.Location = new System.Drawing.Point(220, 68);
            this.textBoxEmployeeName.Name = "textBoxEmployeeName";
            this.textBoxEmployeeName.Size = new System.Drawing.Size(100, 20);
            this.textBoxEmployeeName.TabIndex = 8;
            // 
            // textBoxShiftNumber
            // 
            this.textBoxShiftNumber.Location = new System.Drawing.Point(220, 113);
            this.textBoxShiftNumber.Name = "textBoxShiftNumber";
            this.textBoxShiftNumber.Size = new System.Drawing.Size(100, 20);
            this.textBoxShiftNumber.TabIndex = 9;
            // 
            // textBoxHourlyRate
            // 
            this.textBoxHourlyRate.Location = new System.Drawing.Point(220, 151);
            this.textBoxHourlyRate.Name = "textBoxHourlyRate";
            this.textBoxHourlyRate.Size = new System.Drawing.Size(100, 20);
            this.textBoxHourlyRate.TabIndex = 10;
            // 
            // selectShiftSupervisor
            // 
            this.selectShiftSupervisor.AutoSize = true;
            this.selectShiftSupervisor.Location = new System.Drawing.Point(122, 201);
            this.selectShiftSupervisor.Name = "selectShiftSupervisor";
            this.selectShiftSupervisor.Size = new System.Drawing.Size(106, 17);
            this.selectShiftSupervisor.TabIndex = 11;
            this.selectShiftSupervisor.Text = "Shift Supervisor?";
            this.selectShiftSupervisor.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 328);
            this.Controls.Add(this.selectShiftSupervisor);
            this.Controls.Add(this.textBoxHourlyRate);
            this.Controls.Add(this.textBoxShiftNumber);
            this.Controls.Add(this.textBoxEmployeeName);
            this.Controls.Add(this.textBoxEmployeeNumber);
            this.Controls.Add(this.labelHourlyRate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelEmployeeNumber);
            this.Controls.Add(this.labelEmployeeName);
            this.Controls.Add(this.buttonSearchEmployeeNumber);
            this.Controls.Add(this.buttonCreateEmployee);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee Information";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonCreateEmployee;
        private System.Windows.Forms.Button buttonSearchEmployeeNumber;
        private System.Windows.Forms.Label labelEmployeeName;
        private System.Windows.Forms.Label labelEmployeeNumber;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelHourlyRate;
        private System.Windows.Forms.TextBox textBoxEmployeeNumber;
        private System.Windows.Forms.TextBox textBoxEmployeeName;
        private System.Windows.Forms.TextBox textBoxShiftNumber;
        private System.Windows.Forms.TextBox textBoxHourlyRate;
        private System.Windows.Forms.CheckBox selectShiftSupervisor;
    }
}

