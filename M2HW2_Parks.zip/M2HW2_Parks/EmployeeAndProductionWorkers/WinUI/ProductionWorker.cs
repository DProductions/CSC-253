﻿namespace WinUI
{
    public class ProductionWorker
    {
        public string EmployeeName;
        internal int EmployeeNumber;
        internal double HourlyPayRate;

        public int Shift { get; internal set; }
    }
}