﻿/**
* 24 SEP 2023
* CSC 253
* Daniel Parks
* 
* 
* Project Description:
* Create an Employee class that has propertis for the following data:
*
*    - Employee name
*    - Employee number

* Next, create a class named ProductionWorker that is derived from the Employee class. 
* The ProductionWorker class should have propertis to hold the following data:
*
*    - Shift number (an integer, such as 1,2, or 3)
*    - Hourly pay rate
*
* The workday is divided into two shifts: day and night. The Shift property will hold 
* an integer value representing the shift that the employee works. The day shift is 
* shift 1 and the night shift is shift 2.

* Create an application that creates an object of the ProductionWorker class and lets 
* the user enter data for each of the object's properties. Retrieve the object's 
* properties and display their values.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
    public class Employee
    {
        public string EmployeeName { get; set; }
        public int EmployeeNumber { get; set; }
    }

    public class ProductionWorker : Employee
    {
        public int Shift { get; set; }
        public double HourlyPayRate { get; set; }
    }
    public class ShiftSupervisor : Employee
    {
        public int Shift { get; set; }
        public double HourlyPayRate { get; set; }
    }
}
