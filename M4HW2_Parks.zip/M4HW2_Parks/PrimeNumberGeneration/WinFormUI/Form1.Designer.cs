﻿namespace WinFormUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonFindPrime = new System.Windows.Forms.Button();
            this.buttonClose = new System.Windows.Forms.Button();
            this.listBoxPrimeNumbers = new System.Windows.Forms.ListBox();
            this.textBoxNumber = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonFindPrime
            // 
            this.buttonFindPrime.Location = new System.Drawing.Point(33, 285);
            this.buttonFindPrime.Name = "buttonFindPrime";
            this.buttonFindPrime.Size = new System.Drawing.Size(75, 23);
            this.buttonFindPrime.TabIndex = 0;
            this.buttonFindPrime.Text = "Find Prime";
            this.buttonFindPrime.UseVisualStyleBackColor = true;
            this.buttonFindPrime.Click += new System.EventHandler(this.buttonFindPrime_Click);
            // 
            // buttonClose
            // 
            this.buttonClose.Location = new System.Drawing.Point(114, 285);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(75, 23);
            this.buttonClose.TabIndex = 1;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // listBoxPrimeNumbers
            // 
            this.listBoxPrimeNumbers.FormattingEnabled = true;
            this.listBoxPrimeNumbers.Location = new System.Drawing.Point(38, 81);
            this.listBoxPrimeNumbers.Name = "listBoxPrimeNumbers";
            this.listBoxPrimeNumbers.Size = new System.Drawing.Size(146, 186);
            this.listBoxPrimeNumbers.TabIndex = 2;
            // 
            // textBoxNumber
            // 
            this.textBoxNumber.Location = new System.Drawing.Point(49, 46);
            this.textBoxNumber.Name = "textBoxNumber";
            this.textBoxNumber.Size = new System.Drawing.Size(120, 20);
            this.textBoxNumber.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 39);
            this.label1.TabIndex = 4;
            this.label1.Text = "Please enter a number to find the\r\n    PRIME NUMBERS between 2 \r\n             and" +
    " that number.\r\n";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(224, 322);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxNumber);
            this.Controls.Add(this.listBoxPrimeNumbers);
            this.Controls.Add(this.buttonClose);
            this.Controls.Add(this.buttonFindPrime);
            this.Name = "Form1";
            this.Text = "Prime Number Generation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonFindPrime;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.ListBox listBoxPrimeNumbers;
        private System.Windows.Forms.TextBox textBoxNumber;
        private System.Windows.Forms.Label label1;
    }
}

