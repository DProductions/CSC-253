﻿/**
* 29 OCT 2023
* CSC 253
* Daniel Parks
* Prime number generator. Enter number and display all prime numbers between 2 and that number.
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonFindPrime_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBoxNumber.Text, out int n) && n > 1)
            {
                // Create a list to store the numbers from 2 to n
                List<int> numbers = new List<int>();
                for (int i = 2; i <= n; i++)
                {
                    numbers.Add(i);
                }

                // Use the FindAll method to find prime numbers
                List<int> primeNumbers = numbers.FindAll(IsPrime);

                // Display prime numbers in the ListBox
                listBoxPrimeNumbers.Items.Clear();
                listBoxPrimeNumbers.Items.AddRange(primeNumbers.ConvertAll(x => x.ToString()).ToArray());
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter an integer greater than 1.", "Invalid Input");
            }
        }
       static bool IsPrime(int number)
            {
            if (number <= 1)
                return false;
            if (number == 2)
                return true;
            if (number % 2 == 0)
                return false;

            for (int i = 3; i <= Math.Sqrt(number); i += 2)
            {
                if (number % i == 0)
                    return false;
            }

            return true;
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    }

