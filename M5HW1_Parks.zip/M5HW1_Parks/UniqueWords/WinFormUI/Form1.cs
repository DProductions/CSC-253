﻿/**
* 19 Nov 2023
* CSC 253
* Daniel Parks
* Find unique words in selected file
*/




using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonEvaluate_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                string fileContent = File.ReadAllText(filePath);
                string[] words = fileContent.Split(new char[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                IEnumerable<string> uniqueWords = words.Select(word => word.ToLower()).Distinct();

                listBoxUniqueWords.Items.Clear();
                foreach (string uniqueWord in uniqueWords)
                {
                    listBoxUniqueWords.Items.Add(uniqueWord);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
