﻿namespace WinFormUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonSelectFile = new System.Windows.Forms.Button();
            this.buttonSearchByProductNumber = new System.Windows.Forms.Button();
            this.buttonSearchByDescription = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonSelectFile
            // 
            this.buttonSelectFile.Location = new System.Drawing.Point(17, 78);
            this.buttonSelectFile.Name = "buttonSelectFile";
            this.buttonSelectFile.Size = new System.Drawing.Size(138, 28);
            this.buttonSelectFile.TabIndex = 0;
            this.buttonSelectFile.Text = "Select File";
            this.buttonSelectFile.UseVisualStyleBackColor = true;
            this.buttonSelectFile.Click += new System.EventHandler(this.buttonSelectFile_Click);
            // 
            // buttonSearchByProductNumber
            // 
            this.buttonSearchByProductNumber.Location = new System.Drawing.Point(207, 44);
            this.buttonSearchByProductNumber.Name = "buttonSearchByProductNumber";
            this.buttonSearchByProductNumber.Size = new System.Drawing.Size(131, 23);
            this.buttonSearchByProductNumber.TabIndex = 1;
            this.buttonSearchByProductNumber.Text = "Search By Product Number";
            this.buttonSearchByProductNumber.UseVisualStyleBackColor = true;
            this.buttonSearchByProductNumber.Click += new System.EventHandler(this.buttonSearchByProductNumber_Click);
            // 
            // buttonSearchByDescription
            // 
            this.buttonSearchByDescription.Location = new System.Drawing.Point(207, 124);
            this.buttonSearchByDescription.Name = "buttonSearchByDescription";
            this.buttonSearchByDescription.Size = new System.Drawing.Size(131, 23);
            this.buttonSearchByDescription.TabIndex = 2;
            this.buttonSearchByDescription.Text = "Search By Description";
            this.buttonSearchByDescription.UseVisualStyleBackColor = true;
            this.buttonSearchByDescription.Click += new System.EventHandler(this.buttonSearchByDescription_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(396, 212);
            this.Controls.Add(this.buttonSearchByDescription);
            this.Controls.Add(this.buttonSearchByProductNumber);
            this.Controls.Add(this.buttonSelectFile);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product Search";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonSelectFile;
        private System.Windows.Forms.Button buttonSearchByProductNumber;
        private System.Windows.Forms.Button buttonSearchByDescription;
    }
}

