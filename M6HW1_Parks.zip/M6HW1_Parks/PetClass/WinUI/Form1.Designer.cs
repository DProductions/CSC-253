﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonSelectPet = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonSelectPet
            // 
            this.buttonSelectPet.Location = new System.Drawing.Point(25, 44);
            this.buttonSelectPet.Name = "buttonSelectPet";
            this.buttonSelectPet.Size = new System.Drawing.Size(126, 38);
            this.buttonSelectPet.TabIndex = 0;
            this.buttonSelectPet.Text = "Select Pet";
            this.buttonSelectPet.UseVisualStyleBackColor = true;
            this.buttonSelectPet.Click += new System.EventHandler(this.buttonSelectPet_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(201, 44);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(134, 38);
            this.buttonExit.TabIndex = 1;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 116);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonSelectPet);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pet Class";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonSelectPet;
        private System.Windows.Forms.Button buttonExit;
    }
}

